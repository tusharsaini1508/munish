import numpy as np
import pickle
import os
from deepface import DeepFace

class FaceEmbeddingManager:
    """Utility class for managing face embeddings"""
    
    def __init__(self, embeddings_dir="embeddings"):
        self.embeddings_dir = embeddings_dir
        os.makedirs(embeddings_dir, exist_ok=True)
    
    def load_embedding(self, roll_number):
        """Load embedding for a specific student"""
        embedding_file = os.path.join(self.embeddings_dir, f"{roll_number}_embeddings.pkl")
        
        if os.path.exists(embedding_file):
            with open(embedding_file, 'rb') as f:
                return pickle.load(f)
        return None
    
    def get_all_students(self):
        """Get list of all students with embeddings"""
        students = []
        for file in os.listdir(self.embeddings_dir):
            if file.endswith('_embeddings.pkl'):
                roll_number = file.replace('_embeddings.pkl', '')
                students.append(roll_number)
        return students
    
    def compare_embeddings(self, embedding1, embedding2):
        """Calculate similarity between two embeddings"""
        # Cosine similarity
        dot_product = np.dot(embedding1, embedding2)
        norm1 = np.linalg.norm(embedding1)
        norm2 = np.linalg.norm(embedding2)
        
        if norm1 == 0 or norm2 == 0:
            return 0
        
        similarity = dot_product / (norm1 * norm2)
        return similarity
    
    def find_similar_students(self, target_embedding, threshold=0.8):
        """Find students with similar embeddings"""
        similar_students = []
        
        for student in self.get_all_students():
            student_data = self.load_embedding(student)
            if student_data:
                similarity = self.compare_embeddings(
                    target_embedding, 
                    student_data['average_embedding']
                )
                
                if similarity >= threshold:
                    similar_students.append((student, similarity))
        
        return sorted(similar_students, key=lambda x: x[1], reverse=True)
