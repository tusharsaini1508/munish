import streamlit as st
import pickle
import os
import numpy as np
import matplotlib.pyplot as plt
from face_utils import FaceEmbeddingManager

st.set_page_config(page_title="Embedding Viewer", layout="wide")
st.title("🔍 Face Embedding Viewer")

embedding_manager = FaceEmbeddingManager()

# Get all students
students = embedding_manager.get_all_students()

if students:
    # Select student
    selected_student = st.selectbox("Select Student", students)
    
    if selected_student:
        # Load embedding data
        embedding_data = embedding_manager.load_embedding(selected_student)
        
        if embedding_data:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader(f"📊 Embedding Info: {selected_student}")
                st.write(f"**Roll Number:** {embedding_data['roll_number']}")
                st.write(f"**Embedding Dimension:** {embedding_data['embedding_dimension']}")
                st.write(f"**Valid Images:** {len(embedding_data['valid_images'])}")
                
                # Show embedding statistics
                avg_emb = embedding_data['average_embedding']
                st.write(f"**Mean Value:** {np.mean(avg_emb):.6f}")
                st.write(f"**Std Deviation:** {np.std(avg_emb):.6f}")
                st.write(f"**Min Value:** {np.min(avg_emb):.6f}")
                st.write(f"**Max Value:** {np.max(avg_emb):.6f}")
            
            with col2:
                st.subheader("📈 Embedding Visualization")
                
                # Plot embedding values
                fig, ax = plt.subplots(figsize=(10, 4))
                ax.plot(avg_emb)
                ax.set_title(f'ArcFace Embedding - {selected_student}')
                ax.set_xlabel('Dimension')
                ax.set_ylabel('Value')
                ax.grid(True)
                st.pyplot(fig)
            
            # Show full embedding
            with st.expander("🔢 Full Embedding Vector"):
                st.code(str(avg_emb))
            
            # Find similar students
            st.subheader("👥 Similar Students")
            similar = embedding_manager.find_similar_students(avg_emb)
            
            for student, similarity in similar[:5]:
                if student != selected_student:
                    st.write(f"**{student}:** {similarity:.4f} similarity")

else:
    st.info("No embeddings found. Please collect some face data first.")
