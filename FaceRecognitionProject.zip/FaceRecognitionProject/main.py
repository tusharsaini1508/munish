import streamlit as st
import cv2
import os
import numpy as np
import time
import pickle
import faiss
from deepface import DeepFace

# Configuration
DATASET_DIR = "student_faces"
EMBEDDING_DIR = "face_embeddings"
FAISS_INDEX_DIR = "faiss_indices"
IMAGES_PER_PERSON = 50
EMBEDDING_DIM = 512

# Create directories
for directory in [DATASET_DIR, EMBEDDING_DIR, FAISS_INDEX_DIR]:
    os.makedirs(directory, exist_ok=True)

# Initialize session state
def initialize_session_state():
    if 'img_count' not in st.session_state:
        st.session_state.img_count = 0
    if 'capturing' not in st.session_state:
        st.session_state.capturing = False
    if 'roll_number' not in st.session_state:
        st.session_state.roll_number = ""
    if 'embeddings_generated' not in st.session_state:
        st.session_state.embeddings_generated = False

# Find available camera
def get_available_camera():
    """Find working camera index"""
    for i in range(5):
        try:
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                ret, frame = cap.read()
                if ret:
                    cap.release()
                    return i
        except:
            continue
    return None

# Generate embeddings and create FAISS index
def generate_embeddings_and_faiss_index(roll_number):
    """Generate ArcFace embeddings and create FAISS index"""
    roll_folder = os.path.join(DATASET_DIR, roll_number)
    embeddings = []
    valid_images = []
    
    # Progress bar for embedding generation
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    image_files = [f for f in os.listdir(roll_folder) if f.endswith(('.jpg', '.png', '.jpeg'))]
    
    for i, img_file in enumerate(image_files):
        try:
            img_path = os.path.join(roll_folder, img_file)
            status_text.text(f"Processing image {i+1}/{len(image_files)}: {img_file}")
            
            # Generate ArcFace embedding
            embedding = DeepFace.represent(
                img_path=img_path, 
                model_name="ArcFace",
                enforce_detection=False
            )
            
            if embedding:
                embedding_vector = np.array(embedding[0]['embedding']).astype('float32')
                embeddings.append(embedding_vector)
                valid_images.append(img_file)
            
            progress_bar.progress((i + 1) / len(image_files))
            
        except Exception as e:
            st.warning(f"Failed to process {img_file}: {str(e)}")
    
    if embeddings:
        # Convert to numpy array
        embeddings_array = np.array(embeddings).astype('float32')
        
        # Calculate average embedding
        avg_embedding = np.mean(embeddings_array, axis=0)
        
        # Create FAISS index
        index = faiss.IndexFlatL2(EMBEDDING_DIM)
        index.add(embeddings_array)
        
        # Save data
        embedding_data = {
            'roll_number': roll_number,
            'individual_embeddings': embeddings_array,
            'average_embedding': avg_embedding,
            'valid_images': valid_images,
            'embedding_count': len(embeddings),
            'embedding_dimension': EMBEDDING_DIM
        }
        
        # Save embedding data
        embedding_file = os.path.join(EMBEDDING_DIR, f"{roll_number}_embeddings.pkl")
        with open(embedding_file, 'wb') as f:
            pickle.dump(embedding_data, f)
        
        # Save FAISS index
        faiss_index_file = os.path.join(FAISS_INDEX_DIR, f"{roll_number}_index.faiss")
        faiss.write_index(index, faiss_index_file)
        
        # Save embedding vectors as numpy array
        np_embedding_file = os.path.join(EMBEDDING_DIR, f"{roll_number}_vectors.npy")
        np.save(np_embedding_file, embeddings_array)
        
        status_text.empty()
        progress_bar.empty()
        
        return embedding_data, index
    
    else:
        status_text.empty()
        progress_bar.empty()
        return None, None

# Main Streamlit App
def main():
    initialize_session_state()
    
    st.set_page_config(page_title="Face Data Collector with FAISS", layout="wide")
    st.title("🎓 Advanced Face Data Collection & Embedding System")
    st.markdown("**Collect student face data and generate 512-D ArcFace embeddings with FAISS indexing**")
    
    # Sidebar
    with st.sidebar:
        st.header("📋 Control Panel")
        
        # Roll number input
        roll_number = st.text_input(
            "Enter Student Roll Number", 
            value=st.session_state.roll_number,
            placeholder="e.g., 2023001"
        )
        
        # Instructions
        st.markdown("### 📝 Instructions:")
        st.markdown("""
        1. Enter student roll number
        2. Click **Start Collection**
        3. Look at camera and move head slowly
        4. System captures 50 images automatically
        5. Generates 512-D ArcFace embeddings
        6. Creates FAISS index for similarity search
        """)
        
        # Progress display
        if st.session_state.capturing:
            progress = st.session_state.img_count / IMAGES_PER_PERSON
            st.progress(progress)
            st.write(f"📸 Images: {st.session_state.img_count}/{IMAGES_PER_PERSON}")
            
            # Capture guidance
            if st.session_state.img_count < 15:
                st.info("👀 Look straight ahead")
            elif st.session_state.img_count < 30:
                st.info("↩️ Turn head left slowly")
            elif st.session_state.img_count < 45:
                st.info("↪️ Turn head right slowly")
            else:
                st.info("⬆️⬇️ Look up and down")
    
    # Main content
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📹 Live Camera Feed")
        
        # Camera display
        camera_placeholder = st.empty()
        
        # Control buttons
        btn_col1, btn_col2, btn_col3 = st.columns(3)
        
        with btn_col1:
            start_btn = st.button("🚀 Start Collection", type="primary")
        with btn_col2:
            stop_btn = st.button("⏹️ Stop Collection")
        with btn_col3:
            reset_btn = st.button("🔄 Reset")
    
    with col2:
        st.subheader("📊 Status & Results")
        
        # Status display
        if st.session_state.roll_number:
            st.success(f"**Current Student:** {st.session_state.roll_number}")
        else:
            st.info("Enter roll number to begin")
        
        # Image count
        if st.session_state.img_count > 0:
            st.metric("Images Collected", st.session_state.img_count)
        
        # Results placeholder
        results_placeholder = st.empty()
    
    # Button logic
    if start_btn:
        if not roll_number.strip():
            st.error("⚠️ Please enter a valid roll number!")
        else:
            st.session_state.roll_number = roll_number.strip()
            st.session_state.capturing = True
            st.session_state.img_count = 0
            st.session_state.embeddings_generated = False
            st.rerun()
    
    if stop_btn:
        st.session_state.capturing = False
        st.success(f"✅ Collection stopped. Captured {st.session_state.img_count} images.")
    
    if reset_btn:
        st.session_state.img_count = 0
        st.session_state.capturing = False
        st.session_state.roll_number = ""
        st.session_state.embeddings_generated = False
        st.rerun()
    
    # Camera capture logic
    if st.session_state.capturing and st.session_state.img_count < IMAGES_PER_PERSON:
        camera_index = get_available_camera()
        
        if camera_index is None:
            st.error("❌ No camera found! Please check:")
            st.markdown("""
            - Camera is connected properly
            - No other apps are using the camera
            - Camera permissions are enabled
            - Try restarting the browser
            """)
            st.session_state.capturing = False
        else:
            try:
                cap = cv2.VideoCapture(camera_index)
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                cap.set(cv2.CAP_PROP_FPS, 30)
                
                # Create folder for current student
                roll_folder = os.path.join(DATASET_DIR, st.session_state.roll_number)
                os.makedirs(roll_folder, exist_ok=True)
                
                ret, frame = cap.read()
                
                if ret:
                    # Mirror frame for better UX
                    frame = cv2.flip(frame, 1)
                    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    
                    # Display frame
                    camera_placeholder.image(frame_rgb, channels="RGB", use_column_width=True)
                    
                    # Save image
                    img_path = os.path.join(
                        roll_folder, 
                        f"{st.session_state.roll_number}_{st.session_state.img_count:03d}.jpg"
                    )
                    cv2.imwrite(img_path, frame)
                    st.session_state.img_count += 1
                    
                    # Add delay between captures
                    time.sleep(0.1)
                    
                    if st.session_state.img_count < IMAGES_PER_PERSON:
                        st.rerun()
                    else:
                        st.session_state.capturing = False
                        st.balloons()
                        st.success(f"🎉 Successfully collected {IMAGES_PER_PERSON} images!")
                        st.rerun()
                else:
                    st.error("❌ Failed to read from camera")
                    st.session_state.capturing = False
                
                cap.release()
                
            except Exception as e:
                st.error(f"Camera error: {str(e)}")
                st.session_state.capturing = False
    
    # Generate embeddings after collection
    elif (st.session_state.img_count == IMAGES_PER_PERSON and 
          not st.session_state.embeddings_generated):
        
        with col2:
            st.info("🧠 Generating ArcFace embeddings...")
            
            embedding_data, faiss_index = generate_embeddings_and_faiss_index(
                st.session_state.roll_number
            )
            
            if embedding_data:
                st.session_state.embeddings_generated = True
                
                # Display results
                results_placeholder.success("✅ **Embedding Generation Complete!**")
                results_placeholder.markdown(f"""
                **Student:** {embedding_data['roll_number']}  
                **Images Processed:** {embedding_data['embedding_count']}  
                **Embedding Dimension:** {embedding_data['embedding_dimension']}  
                **FAISS Index:** Created and saved  
                """)
                
                # Show embedding statistics
                avg_emb = embedding_data['average_embedding']
                results_placeholder.markdown(f"""
                **Embedding Stats:**  
                Mean: {np.mean(avg_emb):.6f}  
                Std: {np.std(avg_emb):.6f}  
                Min: {np.min(avg_emb):.6f}  
                Max: {np.max(avg_emb):.6f}  
                """)
                
                # Show first few embedding values
                results_placeholder.markdown("**First 10 embedding values:**")
                results_placeholder.code(str(avg_emb[:10]))
                
                # File locations
                results_placeholder.markdown("**Files saved:**")
                results_placeholder.markdown(f"""
                - Images: `{DATASET_DIR}/{st.session_state.roll_number}/`
                - Embeddings: `{EMBEDDING_DIR}/{st.session_state.roll_number}_embeddings.pkl`
                - FAISS Index: `{FAISS_INDEX_DIR}/{st.session_state.roll_number}_index.faiss`
                - Vectors: `{EMBEDDING_DIR}/{st.session_state.roll_number}_vectors.npy`
                """)
            else:
                results_placeholder.error("❌ Failed to generate embeddings")
    
    elif not st.session_state.capturing and st.session_state.img_count == 0:
        camera_placeholder.info("📷 Camera feed will appear here when collection starts")
    
    # Footer
    st.markdown("---")
    st.markdown("**🔧 System Features:**")
    
    feature_col1, feature_col2, feature_col3 = st.columns(3)
    
    with feature_col1:
        st.markdown("""
        **📸 Data Collection:**
        - Automatic camera detection
        - 50 high-quality images
        - Real-time capture guidance
        """)
    
    with feature_col2:
        st.markdown("""
        **🧠 AI Processing:**
        - ArcFace deep learning model
        - 512-dimensional embeddings
        - Batch processing with progress
        """)
    
    with feature_col3:
        st.markdown("""
        **💾 Data Storage:**
        - FAISS similarity search index
        - Pickle serialization
        - NumPy array format
        """)

if __name__ == "__main__":
    main()
