import streamlit as st
import cv2
import os
import numpy as np
import time
import pickle
from deepface import DeepFace
from mtcnn import MTCNN

# Configuration
DATASET_DIR = "student_faces"
EMBEDDINGS_DIR = "embeddings"
IMAGES_PER_PERSON = 50

# Create directories
os.makedirs(DATASET_DIR, exist_ok=True)
os.makedirs(EMBEDDINGS_DIR, exist_ok=True)

# Initialize session state
def initialize_session_state():
    if 'img_count' not in st.session_state:
        st.session_state.img_count = 0
    if 'capturing' not in st.session_state:
        st.session_state.capturing = False
    if 'roll_number' not in st.session_state:
        st.session_state.roll_number = ""
    if 'embeddings_generated' not in st.session_state:
        st.session_state.embeddings_generated = False

initialize_session_state()

# Configure Streamlit page
st.set_page_config(page_title="Face Data Collector", layout="wide")
st.title("🎓 Student Face Data Collection & Embedding System")

# Sidebar
with st.sidebar:
    st.header("📋 Controls")
    
    # Roll number input
    roll_number = st.text_input(
        "Enter Student Roll Number", 
        value=st.session_state.roll_number,
        placeholder="e.g., 2023001"
    )
    
    # Instructions
    st.markdown("### 📝 Instructions:")
    st.markdown("""
    1. Enter student roll number
    2. Click **Start Collection**
    3. Look at camera and move head slowly
    4. System captures 50 images automatically
    5. Generates 512-D ArcFace embeddings
    """)
    
    # Progress display
    if st.session_state.capturing:
        progress = st.session_state.img_count / IMAGES_PER_PERSON
        st.progress(progress)
        st.write(f"📸 Images: {st.session_state.img_count}/{IMAGES_PER_PERSON}")

# Main content
col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("📹 Live Camera Feed")
    
    # Camera display
    camera_placeholder = st.empty()
    
    # Control buttons
    btn_col1, btn_col2, btn_col3 = st.columns(3)
    
    with btn_col1:
        start_btn = st.button("🚀 Start Collection", type="primary")
    with btn_col2:
        stop_btn = st.button("⏹️ Stop Collection")
    with btn_col3:
        reset_btn = st.button("🔄 Reset")

with col2:
    st.subheader("📊 Status & Results")
    
    # Status display
    if st.session_state.roll_number:
        st.success(f"**Current Student:** {st.session_state.roll_number}")
    else:
        st.info("Enter roll number to begin")
    
    # Image count
    if st.session_state.img_count > 0:
        st.metric("Images Collected", st.session_state.img_count)
    
    # Embedding display placeholder
    embedding_placeholder = st.empty()

# Face detector for quality check
@st.cache_resource
def load_face_detector():
    return MTCNN()

face_detector = load_face_detector()

# Generate embeddings function
def generate_embeddings(roll_number):
    """Generate ArcFace embeddings from collected images"""
    roll_folder = os.path.join(DATASET_DIR, roll_number)
    embeddings = []
    valid_images = []
    
    st.info("🧠 Generating ArcFace embeddings...")
    progress_bar = st.progress(0)
    
    image_files = [f for f in os.listdir(roll_folder) if f.endswith(('.jpg', '.png', '.jpeg'))]
    
    for i, img_file in enumerate(image_files):
        try:
            img_path = os.path.join(roll_folder, img_file)
            
            # Generate embedding using ArcFace
            embedding = DeepFace.represent(
                img_path=img_path, 
                model_name="ArcFace",
                enforce_detection=False
            )
            
            if embedding:
                embedding_vector = np.array(embedding[0]['embedding']).astype('float32')
                embeddings.append(embedding_vector)
                valid_images.append(img_file)
            
            progress_bar.progress((i + 1) / len(image_files))
        
        except Exception as e:
            st.warning(f"Failed to process {img_file}: {str(e)}")
    
    if embeddings:
        # Calculate average embedding
        avg_embedding = np.mean(embeddings, axis=0)
        
        # Save embeddings
        embedding_data = {
            'roll_number': roll_number,
            'individual_embeddings': embeddings,
            'average_embedding': avg_embedding,
            'valid_images': valid_images,
            'embedding_dimension': len(avg_embedding)
        }
        
        embedding_file = os.path.join(EMBEDDINGS_DIR, f"{roll_number}_embeddings.pkl")
        with open(embedding_file, 'wb') as f:
            pickle.dump(embedding_data, f)
        
        st.success(f"✅ Generated embeddings for {len(embeddings)} images")
        return avg_embedding, len(embeddings)
    else:
        st.error("❌ Failed to generate any valid embeddings")
        return None, 0

# Button logic
if start_btn:
    if not roll_number.strip():
        st.error("⚠️ Please enter a valid roll number!")
    else:
        st.session_state.roll_number = roll_number.strip()
        st.session_state.capturing = True
        st.session_state.img_count = 0
        st.session_state.embeddings_generated = False
        st.rerun()

if stop_btn:
    st.session_state.capturing = False
    st.success(f"✅ Collection stopped. Captured {st.session_state.img_count} images.")

if reset_btn:
    st.session_state.img_count = 0
    st.session_state.capturing = False
    st.session_state.roll_number = ""
    st.session_state.embeddings_generated = False
    st.rerun()

# Camera capture logic
if st.session_state.capturing and st.session_state.img_count < IMAGES_PER_PERSON:
    try:
        cap = cv2.VideoCapture(0)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cap.set(cv2.CAP_PROP_FPS, 30)
        
        # Create folder for current student
        roll_folder = os.path.join(DATASET_DIR, st.session_state.roll_number)
        os.makedirs(roll_folder, exist_ok=True)
        
        ret, frame = cap.read()
        
        if ret:
            # Mirror frame for better UX
            frame = cv2.flip(frame, 1)
            
            # Check for face in frame
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            faces = face_detector.detect_faces(frame_rgb)
            
            # Draw face detection boxes
            for face in faces:
                x, y, w, h = face['box']
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(frame, f"Face Detected", (x, y-10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            
            # Convert to RGB for display
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            camera_placeholder.image(frame_rgb, channels="RGB", use_column_width=True)
            
            # Auto-capture with face detection
            if faces:  # Only capture if face is detected
                img_path = os.path.join(
                    roll_folder, 
                    f"{st.session_state.roll_number}_{st.session_state.img_count:03d}.jpg"
                )
                
                # Save original frame (BGR format)
                cv2.imwrite(img_path, cv2.flip(frame, 1))
                st.session_state.img_count += 1
                
                # Add delay between captures
                time.sleep(0.2)
                
                if st.session_state.img_count < IMAGES_PER_PERSON:
                    st.rerun()
                else:
                    st.session_state.capturing = False
                    st.balloons()
                    st.success(f"🎉 Successfully collected {IMAGES_PER_PERSON} images!")
                    st.rerun()
            else:
                st.warning("👤 Please position your face in the camera view")
        else:
            st.error("❌ Failed to access camera")
        
        cap.release()
        
    except Exception as e:
        st.error(f"Camera error: {str(e)}")

# Generate embeddings after collection
elif st.session_state.img_count == IMAGES_PER_PERSON and not st.session_state.embeddings_generated:
    with col2:
        avg_embedding, valid_count = generate_embeddings(st.session_state.roll_number)
        
        if avg_embedding is not None:
            st.session_state.embeddings_generated = True
            
            # Display embedding info
            embedding_placeholder.success(f"🧠 **ArcFace Embedding Generated**")
            embedding_placeholder.write(f"**Dimension:** 512")
            embedding_placeholder.write(f"**Valid Images:** {valid_count}")
            embedding_placeholder.write(f"**Student:** {st.session_state.roll_number}")
            
            # Display embedding vector (first 10 values)
            embedding_placeholder.write("**Embedding Vector (first 10 values):**")
            embedding_placeholder.code(str(avg_embedding[:10]))
            
            # Download button for embedding
            embedding_file = os.path.join(EMBEDDINGS_DIR, f"{st.session_state.roll_number}_embeddings.pkl")
            if os.path.exists(embedding_file):
                with open(embedding_file, 'rb') as f:
                    embedding_placeholder.download_button(
                        label="💾 Download Embedding File",
                        data=f.read(),
                        file_name=f"{st.session_state.roll_number}_embeddings.pkl",
                        mime="application/octet-stream"
                    )

elif not st.session_state.capturing and st.session_state.img_count == 0:
    camera_placeholder.info("📷 Camera will appear here when collection starts")

# Footer
st.markdown("---")
st.markdown("**💡 System Features:**")
col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("✅ **Face Detection**: MTCNN-based quality check")
with col2:
    st.markdown("🧠 **ArcFace Embeddings**: 512-dimensional vectors")
with col3:
    st.markdown("💾 **Data Storage**: Images + embeddings saved")
